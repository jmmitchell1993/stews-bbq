<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Catering</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/stews.css">

</head>
<body>
    <?php require 'base/public/navigation.php'; ?>
    

    <div class="container">

            <h1 class="title_catering">Stews Smoke Shack Catering</h1>
            <h2 class="phone_number_catering">Phone Number: (515) 277-0005</h2>

    </div>


    <?php require 'base/public/footer.php'; ?>
    
</body>
</html>