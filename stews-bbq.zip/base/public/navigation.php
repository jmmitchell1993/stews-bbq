<div class= "nav-container" id= "myTopNav">
  <div class="nav-item"><a href="#">Menu</a></div>
  <div class="nav-item"><a href="index.php#about">Who's Stew</a></div>
  <a href="index.php" class="stewsLogo"><img src="images/nav-logo.png" alt="Stew's Logo"/></a>
  <div class="nav-item"><a href="contact.php">Contact</a></div>
  <div class="nav-item"><a href="delivery.php">Order Now</a></div>
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
      <i class="fa fa-bars"></i>
  </a>
</div>



